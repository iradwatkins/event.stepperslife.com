<?php

namespace Barn2\Plugin\WC_Product_Options\Dependencies\Illuminate\Container;

use Exception;
use Barn2\Plugin\WC_Product_Options\Dependencies\Psr\Container\NotFoundExceptionInterface;
class EntryNotFoundException extends Exception implements NotFoundExceptionInterface
{
    //
}
