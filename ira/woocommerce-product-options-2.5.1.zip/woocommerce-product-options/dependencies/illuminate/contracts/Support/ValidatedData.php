<?php

namespace Barn2\Plugin\WC_Product_Options\Dependencies\Illuminate\Contracts\Support;

use ArrayAccess;
use IteratorAggregate;
interface ValidatedData extends Arrayable, ArrayAccess, IteratorAggregate
{
    //
}
