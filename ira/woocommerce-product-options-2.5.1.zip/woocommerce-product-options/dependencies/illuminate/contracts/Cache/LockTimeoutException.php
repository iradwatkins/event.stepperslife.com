<?php

namespace Barn2\Plugin\WC_Product_Options\Dependencies\Illuminate\Contracts\Cache;

use Exception;
class LockTimeoutException extends Exception
{
    //
}
