<?php

namespace Barn2\Plugin\WC_Product_Options\Dependencies\Illuminate\Contracts\Encryption;

use RuntimeException;
class DecryptException extends RuntimeException
{
    //
}
