<?php

namespace Barn2\Plugin\WC_Product_Options\Dependencies\Illuminate\Contracts\Filesystem;

use Exception;
class FileExistsException extends Exception
{
    //
}
