<?php

namespace Barn2\Plugin\WC_Product_Options\Dependencies\Illuminate\Contracts\Database\Events;

interface MigrationEvent
{
    //
}
