<?php

namespace Barn2\Plugin\WC_Product_Options\Dependencies\Lib\Service;

/**
 * Marker interface to denote a service.
 *
 * @package   Barn2\barn2-lib
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 * @version   1.0
 */
interface Service
{
}
