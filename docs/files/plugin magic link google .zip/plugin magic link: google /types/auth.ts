// TypeScript types and interfaces for authentication system

export interface User {
  id: string
  email: string
  emailVerified: boolean
  image?: string | null
  name?: string | null
  role: UserRole
  isBroker: boolean
  brokerDiscounts?: any
  createdAt: Date
  updatedAt: Date
}

export interface Account {
  id: string
  userId: string
  type: string
  provider: string
  providerAccountId: string
  refresh_token?: string | null
  access_token?: string | null
  expires_at?: number | null
  token_type?: string | null
  scope?: string | null
  id_token?: string | null
  session_state?: string | null
}

export interface Session {
  id: string
  userId: string
  expiresAt: Date
}

export interface VerificationToken {
  identifier: string
  token: string
  expires: Date
}

export enum UserRole {
  CUSTOMER = 'CUSTOMER',
  ADMIN = 'ADMIN'
}

// API Response Types
export interface AuthResponse {
  success: boolean
  message: string
  user?: User
  error?: string
}

export interface GoogleOAuthResponse {
  access_token: string
  id_token: string
  scope: string
  expires_in: number
  token_type: string
}

export interface MagicLinkPayload {
  email: string
  timestamp: number
  ip?: string
}

export interface SessionData {
  userId: string
  email: string
  role: UserRole
  expiresAt: Date
}

// Request/Response interfaces
export interface SignInRequest {
  email: string
  password?: string
  provider?: 'email' | 'google'
}

export interface MagicLinkRequest {
  email: string
  redirectUrl?: string
}

export interface VerifyMagicLinkRequest {
  token: string
  email: string
}

// OAuth Configuration
export interface GoogleOAuthConfig {
  clientId: string
  clientSecret: string
  redirectUri: string
}

// Email Configuration
export interface EmailConfig {
  host: string
  port: number
  secure: boolean
  auth: {
    user: string
    pass: string
  }
  from: string
}

// Session Configuration
export interface SessionConfig {
  secret: string
  maxAge: number
  cookieName: string
  secure: boolean
  httpOnly: boolean
  sameSite: 'strict' | 'lax' | 'none'
}

export interface AuthConfig {
  google: GoogleOAuthConfig
  email: EmailConfig
  session: SessionConfig
  magicLink: {
    expiryMinutes: number
  }
  rateLimit: {
    maxRequests: number
    windowMs: number
  }
}