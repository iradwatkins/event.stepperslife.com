# 🚀 Quick Setup Guide (5 Minutes)

Follow this checklist to get authentication working in your Next.js project quickly.

## ✅ Setup Checklist

### 1. Project Setup (1 minute)
- [ ] Copy all files from `login folder` to your project
- [ ] Install dependencies: `npm install @prisma/client bcryptjs jsonwebtoken nodemailer cookies`
- [ ] Install dev dependencies: `npm install -D prisma @types/bcryptjs @types/jsonwebtoken @types/nodemailer`

### 2. Database Setup (1 minute)
- [ ] Copy content from `database/auth-schema.prisma` to your `prisma/schema.prisma`
- [ ] Run: `npx prisma migrate dev --name add-auth`
- [ ] Run: `npx prisma generate`

### 3. Environment Variables (2 minutes)
Create `.env.local` with these **minimum required** variables:

```bash
# Database
DATABASE_URL="your_database_connection_string"

# Google OAuth (get from Google Cloud Console)
GOOGLE_CLIENT_ID="your_google_client_id.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET="your_google_client_secret"

# Session Management
SESSION_SECRET="your_very_long_random_string_at_least_32_characters"

# Email (for magic links)
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="your_gmail@gmail.com"
SMTP_PASS="your_gmail_app_password"
FROM_EMAIL="your_gmail@gmail.com"

# App URL
NEXTAUTH_URL="http://localhost:3000"
```

### 4. Google OAuth Setup (1 minute)
- [ ] Go to [Google Cloud Console](https://console.cloud.google.com/)
- [ ] Create/select project → APIs & Services → Credentials
- [ ] Create OAuth 2.0 Client ID
- [ ] Add redirect URI: `http://localhost:3000/api/auth/google/callback`
- [ ] Copy Client ID and Secret to `.env.local`

### 5. Test Authentication (30 seconds)
- [ ] Start your app: `npm run dev`
- [ ] Go to: `http://localhost:3000/auth/signin`
- [ ] Try Google sign-in
- [ ] Try magic link with your email

## 🎯 Integration Points

### Protect Routes
```tsx
// Wrap protected pages
import { AuthWrapper } from '@/components/auth/auth-wrapper'

export default function ProtectedPage() {
  return (
    <AuthWrapper>
      <YourPageContent />
    </AuthWrapper>
  )
}
```

### Get Current User
```tsx
// In any component
const [user, setUser] = useState(null)

useEffect(() => {
  fetch('/api/auth/me')
    .then(res => res.json())
    .then(data => setUser(data.user))
}, [])
```

### Sign Out
```tsx
const handleSignOut = async () => {
  await fetch('/api/auth/signout', { method: 'POST' })
  window.location.href = '/auth/signin'
}
```

## 🔧 Quick Customization

### Change User Roles
Edit in `database/auth-schema.prisma`:
```prisma
enum UserRole {
  CUSTOMER
  ADMIN
  MANAGER    // Add your roles
  VIEWER
}
```

### Custom Sign-in Page
Replace content in `pages/auth/signin/page.tsx` with your design.

### Email Templates
Customize emails in `api/auth/send-magic-link/route.ts`.

## 🚨 Production Ready

For production deployment:
- [ ] Set `NEXTAUTH_URL` to your domain
- [ ] Use a secure session secret (32+ characters)
- [ ] Use a proper email service (not Gmail)
- [ ] Enable HTTPS
- [ ] Add production Google OAuth redirect URI

## 💡 Tips

- **Development**: Use Gmail with App Password for testing
- **Production**: Use SendGrid, Mailgun, or similar service
- **Security**: Always use HTTPS in production
- **Database**: PostgreSQL recommended, MySQL also works

## 🆘 Common Issues

| Problem | Solution |
|---------|----------|
| Google OAuth fails | Check redirect URI matches exactly |
| Magic links not sending | Verify Gmail app password (not regular password) |
| Sessions not persisting | Check SESSION_SECRET is set and long enough |
| Database errors | Run `npx prisma db push` to sync schema |

---

**🎉 You're ready! Authentication should now work in your application.**