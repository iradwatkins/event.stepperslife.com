# 🔐 Reusable Authentication System

A complete, production-ready authentication system with Google OAuth and Magic Link support for Next.js applications.

## ✨ Features

- **Google OAuth Integration** - Seamless Google sign-in
- **Magic Link Authentication** - Passwordless email-based login
- **Session Management** - Secure session handling with cookies
- **Email Verification** - User email verification system
- **Role-based Access** - Support for CUSTOMER/ADMIN roles
- **TypeScript Support** - Fully typed interfaces
- **Database Ready** - Prisma schema included
- **Production Tested** - Battle-tested in production environments

## 🚀 Quick Start

### 1. Copy Files to Your Project

Copy the following directories to your Next.js project:

```bash
# API Routes (copy to src/app/api/auth/)
cp -r api/auth/* your-project/src/app/api/auth/

# Pages (copy to src/app/auth/)
cp -r pages/auth/* your-project/src/app/auth/

# Components (copy to src/components/auth/)
cp -r components/auth/* your-project/src/components/auth/

# Utilities (copy to src/lib/)
cp lib/* your-project/src/lib/

# Types (copy to src/types/)
cp types/* your-project/src/types/
```

### 2. Install Dependencies

```bash
npm install @prisma/client bcryptjs jsonwebtoken nodemailer cookies
npm install -D prisma @types/bcryptjs @types/jsonwebtoken @types/nodemailer
```

### 3. Database Setup

Add the auth tables to your `prisma/schema.prisma`:

```prisma
// Copy content from database/auth-schema.prisma
```

Run migrations:

```bash
npx prisma migrate dev --name add-auth
npx prisma generate
```

### 4. Environment Variables

Copy `config/env.example` to your `.env.local`:

```bash
# Required variables
DATABASE_URL="your_database_url"
GOOGLE_CLIENT_ID="your_google_client_id"
GOOGLE_CLIENT_SECRET="your_google_client_secret"
SESSION_SECRET="your_session_secret"
SMTP_HOST="smtp.gmail.com"
SMTP_USER="your_email@gmail.com"
SMTP_PASS="your_app_password"
FROM_EMAIL="your_email@gmail.com"
```

### 5. Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable Google+ API
4. Create OAuth 2.0 credentials
5. Add authorized redirect URIs:
   - `http://localhost:3000/api/auth/google/callback` (development)
   - `https://yourdomain.com/api/auth/google/callback` (production)

### 6. Email Setup (Gmail Example)

1. Enable 2-factor authentication on your Gmail account
2. Generate an App Password:
   - Google Account → Security → 2-Step Verification → App passwords
3. Use the generated password in `SMTP_PASS`

## 📁 File Structure

```
login folder/
├── api/auth/                    # Next.js API routes
│   ├── google/
│   │   ├── route.ts            # Google OAuth initiation
│   │   └── callback/route.ts   # Google OAuth callback
│   ├── me/route.ts             # Get current user
│   ├── signout/route.ts        # Sign out user
│   ├── verify/route.ts         # Email verification
│   ├── send-magic-link/route.ts # Send magic link
│   └── verify-magic-link/route.ts # Verify magic link
├── components/auth/
│   ├── admin-auth-wrapper.tsx  # Admin route protection
│   └── clear-auth-cache.tsx    # Clear auth cache utility
├── pages/auth/
│   ├── signin/page.tsx         # Sign-in page
│   └── verify/page.tsx         # Email verification page
├── lib/
│   ├── auth.ts                 # Core auth utilities
│   └── google-oauth.ts         # Google OAuth helper
├── database/
│   └── auth-schema.prisma      # Database schema
├── config/
│   ├── env.example             # Environment variables
│   └── package-dependencies.json # Required packages
├── types/
│   └── auth.ts                 # TypeScript interfaces
└── docs/
    └── README.md               # This file
```

## 🔧 Usage Examples

### Protecting Routes

```tsx
// components/auth/auth-wrapper.tsx
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

export function AuthWrapper({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    fetch('/api/auth/me')
      .then(res => res.json())
      .then(data => {
        if (data.user) {
          setUser(data.user)
        } else {
          router.push('/auth/signin')
        }
        setLoading(false)
      })
  }, [])

  if (loading) return <div>Loading...</div>
  if (!user) return null

  return <>{children}</>
}
```

### Getting Current User

```tsx
// hooks/use-auth.ts
import { useEffect, useState } from 'react'

export function useAuth() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/auth/me')
      .then(res => res.json())
      .then(data => {
        setUser(data.user)
        setLoading(false)
      })
  }, [])

  return { user, loading }
}
```

### Custom Sign-in Component

```tsx
// components/custom-signin.tsx
'use client'

import { useState } from 'react'

export function CustomSignIn() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)

  const handleGoogleSignIn = () => {
    window.location.href = '/api/auth/google'
  }

  const handleMagicLink = async () => {
    setLoading(true)
    await fetch('/api/auth/send-magic-link', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    })
    setLoading(false)
    alert('Magic link sent! Check your email.')
  }

  return (
    <div className="space-y-4">
      <button onClick={handleGoogleSignIn}>
        Sign in with Google
      </button>

      <div>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
        />
        <button onClick={handleMagicLink} disabled={loading}>
          Send Magic Link
        </button>
      </div>
    </div>
  )
}
```

## 🔐 Security Features

- **Session Security**: Secure HTTP-only cookies
- **CSRF Protection**: Built-in CSRF protection
- **Rate Limiting**: Configurable rate limiting
- **Email Verification**: Required email verification
- **Token Expiration**: Configurable token expiry
- **Secure Headers**: Security headers included

## 🛠 Customization

### Adding New OAuth Providers

1. Create new API route in `api/auth/[provider]/`
2. Add provider configuration to types
3. Update auth utilities

### Custom User Roles

```prisma
enum UserRole {
  CUSTOMER
  ADMIN
  MODERATOR  // Add new roles here
  SUPER_ADMIN
}
```

### Custom Email Templates

Modify the email templates in the magic link route:

```typescript
// api/auth/send-magic-link/route.ts
const emailHtml = `
  <h1>Your Custom Brand</h1>
  <p>Click the link below to sign in:</p>
  <a href="${magicLink}">Sign In</a>
`
```

## 📊 Database Relationships

The auth system provides basic User/Account/Session models. To extend:

```prisma
model User {
  // ... existing fields

  // Add your custom relations
  posts     Post[]
  comments  Comment[]
  profile   Profile?
}

model Profile {
  id     String @id @default(cuid())
  userId String @unique
  bio    String?
  avatar String?
  user   User   @relation(fields: [userId], references: [id])
}
```

## 🚨 Production Checklist

- [ ] Set `NEXTAUTH_SECRET` to a secure random string
- [ ] Use HTTPS in production (`COOKIE_SECURE=true`)
- [ ] Configure proper CORS settings
- [ ] Set up proper error monitoring
- [ ] Configure email delivery service (not Gmail)
- [ ] Set up database backups
- [ ] Configure rate limiting
- [ ] Review and test all auth flows

## 🔍 Troubleshooting

### Common Issues

1. **Google OAuth not working**
   - Verify redirect URIs in Google Console
   - Check `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`

2. **Magic links not sending**
   - Check SMTP configuration
   - Verify Gmail app password
   - Check spam folder

3. **Sessions not persisting**
   - Verify `SESSION_SECRET` is set
   - Check cookie configuration
   - Ensure HTTPS in production

### Debug Mode

Add this to your environment for detailed logging:

```
DEBUG=auth:*
NODE_ENV=development
```

## 📄 License

This authentication system is provided as-is for educational and commercial use. Please ensure you comply with all relevant privacy and security regulations in your jurisdiction.

## 🤝 Support

This system has been battle-tested in production at GangRun Printing. For issues or questions, refer to the original implementation or adapt as needed for your use case.

---

**Built with ❤️ for the developer community**